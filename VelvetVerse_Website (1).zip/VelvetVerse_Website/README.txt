VELVETVERSE WEBSITE — QUICK START

1. Download and extract VelvetVerse_Website.zip.
2. Open the VelvetVerse_Website folder.
3. Double-click index.html to open the website in your browser.
4. Test Stories, Writers, Upload a Story, likes, and comments.

IMPORTANT
This starter website stores stories, likes, comments, and the site name only in the current browser on this device. It does not yet share user uploads or comments between visitors. Publishing the HTML online makes the page public, but shared uploads/comments need a secure backend/database.

To publish with GitHub Pages:
1. Sign in to GitHub and create a repository.
2. Upload index.html from this folder.
3. In repository Settings, open Pages and follow the publishing instructions.
4. Use the public URL GitHub provides.
