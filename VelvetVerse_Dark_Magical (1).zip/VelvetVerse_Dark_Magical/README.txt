VELVETVERSE — DARK, ELEGANT & MAGICAL EDITION

Files:
- index.html: upload this file to the root of your GitHub repository, replacing the old index.html.

Style:
Black, midnight purple, burgundy, and subtle pink accents.
Includes genre filters for Dark Romance, Fantasy, Mystery, Thriller, Teen Drama, Supernatural, Romance, Drama, School Life, Self-Discovery, and Adventure.

Important:
This is a static website prototype. Stories, likes, and comments are stored only in each visitor's own browser and are not shared online. Shared accounts and community features require a secure backend/database.

GitHub Pages update:
1. Open your repository.
2. Open index.html and choose the pencil/Edit button, or use Add file > Upload files to upload this new index.html.
3. Commit the changes.
4. Wait briefly, then refresh your published website.
